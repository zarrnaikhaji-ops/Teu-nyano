VANTA CAMERA — SOURCE PROJECT APK
=================================

Isi ZIP:
- app/src/main/assets/index.html : UI Liquid Glass + kamera web (HTML/CSS/JS)
- Android Studio project : WebView Android wrapper yang membuka aset melalui HTTPS virtual origin
- Camera permission + WebChromeClient grant untuk getUserMedia

CARA BUILD APK:
1. Install Android Studio versi terbaru.
2. Extract ZIP.
3. Android Studio > Open > pilih folder VantaCamera_APK_Project.
4. Tunggu Gradle Sync (butuh internet untuk mengunduh Android Gradle Plugin dan AndroidX WebKit).
5. Hubungkan HP atau pilih emulator. Pastikan emulator punya kamera virtual.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK debug bisa ditemukan di app/build/outputs/apk/debug/app-debug.apk.

CATATAN PENTING:
- Project ini adalah source project siap dibuka/build di Android Studio, bukan APK yang sudah ditandatangani.
- Android Studio/SDK/Gradle dibutuhkan untuk menghasilkan APK.
- Aplikasi meminta izin kamera saat pertama kali dibuka.
- Kamera depan/belakang, foto, video, zoom, color look, grid, dan liquid ripple diproses di halaman HTML.
- Torch hanya tersedia jika perangkat dan WebView mendukungnya.
- 4K/8K dan 60/120 FPS bergantung sensor, driver, perangkat, dan browser WebView. UI tidak dapat menambah kemampuan hardware.
- Preview dan output canvas dibatasi maksimum sisi 1920px untuk menjaga stabilitas/performa ponsel; ini bukan perekaman native 8K.
- Perekaman browser umumnya menghasilkan WebM; kompatibilitas codec tergantung Android System WebView.
- Untuk hasil kamera profesional dengan stabilisasi hardware, HDR, RAW, 4K/60, atau MP4 native, diperlukan implementasi Android CameraX/Camera2 native, bukan hanya HTML/WebView.

TROUBLESHOOTING:
- Jika kamera ditolak, buka Android Settings > Apps > Vanta Camera > Permissions > Camera > Allow.
- Update Android System WebView dan Chrome.
- Tutup aplikasi lain yang sedang memakai kamera.
- Build menggunakan compileSdk 35; Android Studio mungkin meminta SDK Platform 35 diunduh.
